module.exports = {
  printWidth: 100,
  semi: false,
  singleQuote: true,
  trailingComma: 'none'
}
